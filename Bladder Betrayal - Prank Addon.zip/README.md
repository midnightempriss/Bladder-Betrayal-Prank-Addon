# 🚽 Bladder Betrayal - Prank Addon

## 😈 The Ultimate WoW Prank Experience

**Bladder Betrayal** is the perfect prank addon for World of Warcraft that will leave your friends, guildmates, and fellow players in stitches! This sneaky little addon creates hilariously awkward moments by automatically triggering embarrassing "bladder emergency" emotes at the most unexpected times.

## 🎯 What Does It Do?

This addon transforms your character into an unpredictable source of comedy by:

- **🕐 Automatically triggers every 10 minutes** - No warning, no control, just pure comedic timing
- **💬 Sends embarrassing emotes** - Your character will suddenly have "accidents" in public
- **🔊 Plays custom sound effects** - Audio cues that only you can hear when the prank activates
- **🤫 Completely stealth operation** - No visible interface, no commands to give it away
- **🎭 Perfect for social situations** - Raids, dungeons, cities, anywhere players gather

## 🎪 Perfect Use Cases

### Guild Pranks
- Install it on a friend's computer during a guild meeting
- Watch as they try to explain their character's sudden "emergencies"
- Perfect for breaking tension during serious raid discussions

### Roleplay Scenarios
- Adds unexpected comedy to serious RP events
- Creates memorable moments that become guild legends
- Perfect conversation starter in social hubs

### Streaming Content
- Creates hilarious moments for Twitch/YouTube content
- Generates unexpected viewer reactions
- Perfect for variety streamers who play WoW

### Party Entertainment
- Install on multiple guild members for coordinated chaos
- Creates inside jokes that last for months
- Perfect ice-breaker for new guild members

## 🚨 The Prank in Action

Every 10 minutes, without warning, your character will:

1. **🕺 Start doing a frantic little dance** - Crossing legs desperately
2. **😳 Have a "bladder emergency"** - Complete with embarrassing details
3. **🔊 Play a custom sound** - Only you hear the audio cue
4. **💬 Send the emote to chat** - Everyone nearby sees the message

**Example Output:**
```
[YourCharacter] suddenly crosses their legs and starts to do a frantic little dance. But it's too late... they've had an accident. A dark stain spreads as they blush bright red, realizing they've just peed their pants in public.
```

## 🔒 Stealth Features

- **No visible interface** - Completely hidden from view
- **No slash commands** - Can't be accidentally disabled
- **Auto-starts on login** - No setup required, just install and forget
- **Only way to stop** - Disable the entire addon (victim has to figure this out!)

## 📦 Installation

1. **Download the addon** and extract to your WoW AddOns folder:
   ```
   World of Warcraft\_retail_\Interface\AddOns\
   ```

2. **Optional: Add custom sounds** 
   - Place your sound file in the `Sounds` folder
   - Name it `pee-shamesound.ogg` (or edit Core.lua for different names)

3. **Launch WoW** - The addon starts automatically, no configuration needed!

## ⚠️ Disclaimer

**Use Responsibly!** This addon is designed for harmless fun between friends. Always ensure:
- ✅ You have permission to install software on the computer
- ✅ The person will appreciate the humor
- ✅ It's appropriate for the gaming environment
- ✅ You're prepared to help remove it when the fun is over

## 🎉 Why Choose Bladder Betrayal?

- **🎯 Perfect Timing** - 10-minute intervals create unpredictable moments
- **😂 Guaranteed Laughs** - Embarrassing content that's sure to get reactions
- **🕵️ Stealth Design** - Victim can't easily figure out what's happening
- **🎨 Customizable** - Add your own sounds for personalized pranks
- **🛡️ Safe Prank** - No game-breaking effects, just harmless fun

## 📞 Support

Having trouble with your prank? Check that:
- Addon is properly installed in the AddOns folder
- Character has chat permissions in the current zone
- Custom sound files are in the correct format and location

---

**Remember: The best pranks are the ones everyone can laugh about later!** 😄

*Bladder Betrayal - Because everyone needs a little unexpected humor in their WoW experience!*